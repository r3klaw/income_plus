<!DOCTYPE HTML>
<?PHP
require 'functions.php';
header ('refresh:7; url=index.php');
?>

<html>
	<?PHP includeHead('Microfinance Management',1) ?>
		
	<body>
		<div class="content_center" style="margin-top:2em;">
			<img src="ico/mangoo_l.png" />
			<?PHP include 'version.html'; ?>
		</div>
	</body>
</html>