
<?PHP
/**
	*	Password pepper
	*/
	$pepper = 'pc?yACRCM=';
?>